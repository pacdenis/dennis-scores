---
title_ru: "Симфонические зарисовки"
title_en: "Symphonic Sketches"
forces_ru: "Камерный оркестр"
forces_en: "Chamber orchestra"
duration: "6:05"
difficulty_ru: "Продвинутый уровень"
difficulty_en: "Advanced"
category: orchestral
tags: [concertnaya]
version: "v1.0"
date_created: 2025-05-05
audio_url: ""
pdf_url: ""
buy_url: "#"
---
